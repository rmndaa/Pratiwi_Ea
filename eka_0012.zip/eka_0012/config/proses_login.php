<?php
session_start();
include("koneksi.php");
$username = $_POST['username'];
$password = $_POST['password'];
$login = mysqli_query($config, "select * from user where username='$username' && password='$password'");
$cek = mysqli_num_rows($login);
if ($cek > 0) {
	$data = mysqli_fetch_assoc($login);

	if ($data['role'] == "Admin") {
		$_SESSION['username'] = $username;
		$_SESSION['role'] = "Admin";
		header('location:../Admin/index.php');

	} else if ($data['role'] == "Petugas") {
		$_SESSION['username'] = $username;
		$_SESSION['role'] = "Petugas";
		header('location:../Petugas/index.php');

	}
} else {
	echo "<script type='text/javascript'>alert('Username Atau Password Anda Salah !!!'); history.back(self);</script'";
}
?>