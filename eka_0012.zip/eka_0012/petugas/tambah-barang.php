<?php
session_start();
 if (!isset ($_SESSION['username'])){
  header(header:"location:../index.php");
  exit();
 }
 ?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">


    <title>Tambah Barang</title>
    <style>
    /* ============================= */
/*          GLOBAL STYLE         */
/* ============================= */

body {
    background-color: #0000;
    font-family: Georgia, serif;
    color : black
}

/* ============================= */
/*         NAVBAR STYLE          */
/* ============================= */

.bg-Thistle {
    background-color: Thistle !important; /* Warna pink */
}

.navbar-brand,
.navbar-nav .nav-link {
    color: black !important;
    font-weight: bold ;
}

.navbar-nav .nav-link:hover {
    color: #ffebf0 !important; /* Warna hover lebih soft */
}

/* ============================= */
/*        CONTAINER STYLE        */
/* ============================= */

.container-box {
    background: #fff;
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
}
.text-center {
    text-align: center; /* Hanya teks ini yang di tengah */
    margin-top: 25px;
     margin-bottom: 25px;
}

h3 {
    font-family: Lucida Handwriting, Cursive;
    font-size: 35px;
    font-weight: bold;
    color: black;
}

</style>

</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-Thistle">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">App Kasir</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active " aria-current="page" href="index.php">Home</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle " href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Penjualan
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <li><a class="dropdown-item" href="tambah-penjualan.php">Tambah Data</a></li>
                            <li><a class="dropdown-item" href="tampil-penjualan.php">Tampil Data</a></li>
                            <li><a class="dropdown-item" href="cetak-penjualan.php" >Cetak Data</a></li>
                        </ul>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle " href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Barang
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <li><a class="dropdown-item" href="tambah-barang.php">Tambah Barang</a></li>
                            <li><a class="dropdown-item" href="tampil-barang.php">Tampil Barang</a></li>
                            <li><a class="dropdown-item" href="cetak-barang.php" >Cetak Barang</a></li>
                        </ul>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle " href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Pelanggan
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <li><a class="dropdown-item" href="tambah-pelanggan.php">Tambah Pelanggan</a></li>
                            <li><a class="dropdown-item" href="tampil-pelanggan.php">Tampil Pelanggan</a></li>
                            <li><a class="dropdown-item" href="cetak-pelanggan.php" >Cetak Pelanggan</a></li>
                        </ul>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="../config/logout.php" onclick="return confirm('Apakah Anda Yakin Ingin Logout ???')">Logout</a>
                    </li>
                    <!-- Additional Navigation Items -->
                </ul>
            </div>
        </div>
    </nav>





<div class="container-fluid">
    <div class="text-center">
  <h3>Tambah Barang</h3>
</div>
</div>


<div class="row">
    <div class="table">
<form class="row g-3" action="simpan-barang.php" method="post">
  <div class="col-12">
    <label for="inputAddress" class="form-label">ID Barang</label>
    <input type="text" class="form-control" name="id_barang" id="inputAddress" placeholder="ID Barang">
  </div>
  <div class="col-12">
    <label for="inputAddress2" class="form-label">Nama Barang</label>
    <input type="text" class="form-control" name="nama_barang" id="inputAddress2" placeholder="Nama Barang">
  </div>
  <div class="col-12">
    <label for="inputAddress" class="form-label">Harga Barang</label>
    <input type="text" class="form-control" name="harga" id="inputAddress" placeholder="Harga Barang">
  </div>
  <div class="col-12">
    <label for="inputAddress2" class="form-label">Stok Barang</label>
    <input type="text" class="form-control" name="stok" id="inputAddress2" placeholder="Stok Barang">
  </div>
</div>
  <div class="col-12">
    <button type="submit" class="btn btn-primary">Simpan</button>
  </div>
</form>
  

  </div>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="../assets/js/bootstrap.bundle.min.js"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>
