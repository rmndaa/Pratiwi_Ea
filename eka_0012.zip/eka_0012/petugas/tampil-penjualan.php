<?php
session_start();
 if (!isset ($_SESSION['username'])){
  header(header:"location:../index.php");
  exit();
 }
 ?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">


    <title>Tampil Penjualan</title>
    <style>
    /* ============================= */
/*          GLOBAL STYLE         */
/* ============================= */

body {
    background-color: #0000;
    font-family: Georgia, serif;
    color : black
}

/* ============================= */
/*         NAVBAR STYLE          */
/* ============================= */

.bg-Thistle {
    background-color: #D8BFD8 !important; /* Warna pink */
}

.navbar-brand,
.navbar-nav .nav-link {
    color: black !important;
    font-weight: bold;
}

.navbar-nav .nav-link:hover {
    color: #ffebf0 !important; /* Warna hover lebih soft */
}

/* ============================= */
/*        CONTAINER STYLE        */
/* ============================= */

.container-box {
    background: #fff;
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
}

.text-center {
    text-align: center; /* Hanya teks ini yang di tengah */
    margin-top: 25px;
     margin-bottom: 25px;
}

h3 {
    font-family: Lucida Handwriting, Cursive;
    font-size: 35px;
    font-weight: bold;
    color: black;
}

/* ============================= */
/*         TABLE STYLE           */
/* ============================= */

.table {
    border-radius: 10px;
    overflow: hidden;
}

.table thead {
    background: Pink; /* Background header tabel */
    color: black;
}

.table tbody tr:hover {
    background: #f8f9fa;
    transition: 0.3s;
}
</style>

</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-Thistle">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">App Kasir</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active " aria-current="page" href="index.php">Home</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle " href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Penjualan
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <li><a class="dropdown-item" href="tambah-penjualan.php">Tambah Data</a></li>
                            <li><a class="dropdown-item" href="tampil-penjualan.php">Tampil Data</a></li>
                            <li><a class="dropdown-item" href="cetak-penjualan.php" >Cetak Data</a></li>
                        </ul>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle " href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Barang
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <li><a class="dropdown-item" href="tambah-barang.php">Tambah Barang</a></li>
                            <li><a class="dropdown-item" href="tampil-barang.php">Tampil Barang</a></li>
                            <li><a class="dropdown-item" href="cetak-barang.php" >Cetak Barang</a></li>
                        </ul>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle " href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Pelanggan
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <li><a class="dropdown-item" href="tambah-pelanggan.php">Tambah Pelanggan</a></li>
                            <li><a class="dropdown-item" href="tampil-pelanggan.php">Tampil Pelanggan</a></li>
                            <li><a class="dropdown-item" href="cetak-pelanggan.php" >Cetak Pelanggan</a></li>
                        </ul>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="../config/logout.php" onclick="return confirm('Apakah Anda Yakin Ingin Logout ???')">Logout</a>
                    </li>
                    <!-- Additional Navigation Items -->
                </ul>
            </div>
        </div>
    </nav>


    <div class="container-fluid">
        <div class="text-center">
        <h3 class="m-3">Tampil Penjualan</h3>
    </div>
</div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>ID Penjualan</th>
                        <th>Tanggal Penjualan</th>
                        <th>Nama Pelanggan</th>
                        <th>Total Harga</th>
                        <th>Nama Barang</th>
                        <th>Jumlah</th>
                        <th>Harga Satuan</th>
                        <th>Subtotal</th>
                        <th>Opsi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Include file koneksi database
                    include("../config/koneksi.php");
                    $i = 1; // Nomor urut
                    $query = "
    SELECT 
        p.id_penjualan,
        p.tgl_penjualan,
        p.id_pelanggan,
        pl.nama AS nama_pelanggan,
        p.total,
        dp.id_barang,
        b.nama_barang,
        dp.jumlah,
        dp.harga,
        dp.subtotal
    FROM 
        penjualan p
    INNER JOIN 
        detail_penjualan dp ON p.id_penjualan = dp.id_penjualan
    INNER JOIN 
        pelanggan pl ON p.id_pelanggan = pl.id_pelanggan
    INNER JOIN 
        barang b ON dp.id_barang = b.id_barang
    ORDER BY 
        p.id_penjualan, dp.id_barang";
                    $result = mysqli_query($config, $query);
                    // Jika query gagal, tampilkan error
                    if (!$result) {
                        echo "<tr><td colspan='11'>Error: " . mysqli_error($config) . "</td></tr>";
                    } else {
                        // Iterasi hasil query
                        while ($data = mysqli_fetch_assoc($result)) {
                            echo "
        <tr>
            <td>$i</td>
            <td>{$data['id_penjualan']}</td>
            <td>{$data['tgl_penjualan']}</td>
            <td>{$data['nama_pelanggan']}</td>
            <td>{$data['total']}</td>
            <td>{$data['nama_barang']}</td>
            <td>{$data['jumlah']} Pcs</td>
            <td>Rp. {$data['harga']}</td>
            <td>Rp. {$data['subtotal']}</td>
            <td>                   
                <a href='hapus-penjualan.php?id_penjualan=$data[id_penjualan]' class='btn btn-danger' title='Hapus Penjualan'>Hapus</a>
            </td>
        </tr>";
                            $i++;
                        }
                    }
                    ?>

                </tbody>
            </table>
        </div>

    <script src="../assets/js/bootstrap.bundle.min.js"></script>
</body>

</html>