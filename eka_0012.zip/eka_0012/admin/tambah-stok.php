<?php
session_start();
 if (!isset ($_SESSION['username'])){
  header(header:"location:../index.php");
  exit();
 }
 ?>

<?php
// Koneksi ke database
include("../config/koneksi.php");

// Ambil ID barang dari parameter
$id_barang = $_GET['id_barang'] ?? null;

// Proses form jika ada data yang dikirim
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$stok_tambah = (int)$_POST['stok_tambah'];

	if ($stok_tambah > 0) {
		// Update stok barang
		$query = " UPDATE barang SET stok = stok + $stok_tambah WHERE id_barang = '$id_barang'";
		if (mysqli_query($config, $query)) {
			echo "<script>alert('Data Stok Barang Berhasil ditambahkan !!!');location.href=('Tampil-Barang.php');</script>";
		} else {
			echo "Gagal menambahkan stok: " . mysql_error($config);
		}
	} else {
		echo "<script type='text/javascript'>alert(Jumlah stok harus lebih dari 0 !!!'); history.back(self);</script>'";
	}
}
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" >

    <title>Tambah Stok</title>

        <style>
    /* ============================= */
/*          GLOBAL STYLE         */
/* ============================= */

body {
    background-color: #0000;
    font-family: Georgia, serif;
    color : black
}

/* ============================= */
/*         NAVBAR STYLE          */
/* ============================= */

.bg-info {
    background-color: PowderBlue !important; /* Warna pink */
}

.navbar-brand,
.navbar-nav .nav-link {
    color: black !important;
    font-weight: bold ;
}

.navbar-nav .nav-link:hover {
    color: #ffebf0 !important; /* Warna hover lebih soft */
}

/* ============================= */
/*        CONTAINER STYLE        */
/* ============================= */

.container-box {
    background: #fff;
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
}

.text-center {
    text-align: center; /* Hanya teks ini yang di tengah */
    margin-top: 30px;
     margin-bottom: 30px;
}

h3 {
    font-family: Lucida Handwriting, Cursive;
    font-size: 40px;
    font-weight: bold;
    color: black;
}

</style>
  </head>
  <body>
    
    <nav class="navbar navbar-expand-lg navbar-light bg-info">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">App Kasir</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">Home</a>
        </li>
           <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Barang
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="tambah-barang.php">Tambah Barang</a></li>
            <li><a class="dropdown-item" href="tampil-barang.php">Tampil Barang</a></li>
            <li><a class="dropdown-item" href="cetak-barang.php" >Cetak Barang</a></li>
          </ul>
        </li>
         <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Pelanggan
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="tambah-pelanggan.php">Tambah Pelanggan</a></li>
            <li><a class="dropdown-item" href="tampil-pelanggan.php">Tampil Pelanggan</a></li>
            <li><a class="dropdown-item" href="cetak-pelanggan.php" >Cetak Pelanggan</a></li>
          </ul>
        </li>
         <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            User
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="tambah-user.php">Tambah User</a></li>
            <li><a class="dropdown-item" href="tampil-user.php">Tampil User</a></li>
            <li><a class="dropdown-item" href="cetak-user.php" >Cetak User</a></li>
          </ul>
        </li>
         <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="../config/logout.php" onclick="return confirm('Apakah Anda Yakin Ingin Logout ???')">Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>


<div class="container-fluid">
  <div class="text-center">
	<h3>Tambah Stok Barang</h3>
</div>
</div>
	<div class="row">
    <div class="table">
		
		<form action="" method="POST">
			<label for="stok_tambah" class="form-label">Jumlah Tambah Stok:</label>
			<input type="number" id="stok_tambah" class="form-control" name="stok_tambah" required placeholder="Jumlah Stok Barang">
			<br>
			<button type="submit" class="btn btn-primary">Tambah Stok</button>
		</form>
	</div>
</div>