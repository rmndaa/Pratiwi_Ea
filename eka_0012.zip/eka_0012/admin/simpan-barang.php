<?php
// Koneksi ke database
include('../config/koneksi.php'); // Pastikan file koneksi.php benar

// Ambil data dari form
$id_barang = $_POST['id_barang'];
$nama_barang = $_POST['nama_barang'];
$harga = $_POST['harga'];
$stok = $_POST['stok'];

// Cek apakah ada data yang kosong
if (empty($id_barang) || empty($nama_barang) || empty($harga) || empty($stok)) {
    echo "<script>alert('Semua data harus diisi!'); window.location.href='tambah-barang.php';</script>";
    exit;
}

// Cek apakah ID Barang sudah ada
$query = "SELECT id_barang FROM barang WHERE id_barang = '$id_barang'";
$result = mysqli_query($config, $query);

if (!$result) {
    die("Query error: " . mysqli_error($config)); // Debugging jika ada error
}

if (mysqli_num_rows($result) > 0) {
    echo "<script>alert('ID Barang sudah ada. Gunakan ID lain.'); window.location.href='tambah-barang.php';</script>";
} else {
    // Simpan data ke database
    $query_insert = "INSERT INTO barang (id_barang, nama_barang, harga, stok) VALUES ('$id_barang', '$nama_barang', '$harga', '$stok')";
    
    if (mysqli_query($config, $query_insert)) {
        echo "<script>alert('Barang berhasil ditambahkan!'); window.location.href='tampil-barang.php';</script>";
    } else {
        echo "<script>alert('Gagal menyimpan data: " . mysqli_error($config) . "'); window.location.href='tambah-barang.php';</script>";
    }
}
?>
