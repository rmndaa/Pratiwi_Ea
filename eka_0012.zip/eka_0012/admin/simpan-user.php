<?php
// Koneksi ke database
include('../config/koneksi.php'); // Pastikan koneksi ke database sudah benar

// Ambil data dari form
$id_user = $_POST['id_user'];
$nama = $_POST['nama'];
$username = $_POST['username'];
$password = $_POST['password'];
$role = $_POST['role'];

// Cek apakah ID user sudah ada di database
$query = "SELECT * FROM user WHERE id_user = '$id_user'";
$result = mysqli_query($config, $query);

if (mysqli_num_rows($result) > 0) {
    // Jika ID sudah ada, beri peringatan
    echo "<script>alert('ID User sudah terdaftar. Silakan masukkan ID yang berbeda.'); window.location.href='tambah-user.php';</script>";
} else {
    // Jika ID tidak duplikat, simpan data ke database
    $query_insert = "INSERT INTO user (id_user, nama, username, password) VALUES ('$id_user', '$nama', '$username', '$password', '$role')";
    
    if (mysqli_query($conn, $query_insert)) {
        echo "<script>alert('User berhasil ditambahkan!'); window.location.href='tampil-user.php';</script>";
    } else {
        echo "<script>alert('Terjadi kesalahan saat menyimpan data.'); window.location.href='tambah-user.php';</script>";
    }
}
?>