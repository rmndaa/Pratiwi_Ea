<?php include "tampil-user.php" ?>
include("../config/koneksi.php");
<?php
$hasil = $_REQUEST['id_user'];
$perintah = mysqli_query($config, "delete from user where id_user='$hasil'");
if ($perintah) {
	echo "<script>alert('Data User Berhasil Di Hapus!');
	location.href=('tampil-user.php');
	</script>;
	";
} else {
	echo mysqli_error($config);
	//echo "<script>alert('Data Barang Gagal Di Hapus!'); history.back(self)</script>;";
}
?>