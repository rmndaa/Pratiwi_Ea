<?php include "tampil-pelanggan.php" ?>
include("../config/koneksi.php");
<?php
$hasil = $_REQUEST['id_pelanggan'];
$perintah = mysqli_query($config, "delete from pelanggan where id_pelanggan='$hasil'");
if ($perintah) {
	echo "<script>alert('Data Pelanggan Berhasil Di Hapus!');
	location.href=('tampil-pelanggan.php');
	</script>;
	";
} else {
	echo mysqli_error($config);
	//echo "<script>alert('Data Barang Gagal Di Hapus!'); history.back(self)</script>;";
}
?>