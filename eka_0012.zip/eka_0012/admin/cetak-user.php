<?php
session_start();
 if (!isset ($_SESSION['username'])){
  header(header:"location:../index.php");
  exit();
 }
 ?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" >
    <title>Cetak User</title>
  <script>
  document.addEventListener("DOMContentLoaded", function() {
      window.print();

      // Deteksi jika pengguna membatalkan print
      window.addEventListener("afterprint", function() {
          window.location.href = document.referrer; // Kembali ke halaman sebelumnya
      });

      // Jika browser tidak mendukung event afterprint, tambahkan fallback
      setTimeout(function() {
          window.location.href = document.referrer;
      }, 1000);
  });
</script>


  <style>
  @media print {
      h2 {
          margin-bottom: 20px;
          font-size: 24px;
          font-weight: bold;
      }

      table {
          width: 90%;
          border-collapse: collapse;
          margin: 0 auto; /* Biar tetap di tengah */
          border: 2px solid black;
      }

      th, td {
          padding: 10px;
          text-align: center;
          border: 2px solid black;
      }

      th {
          background-color: #f8f9fa; /* Warna header lebih soft */
          color: black;
          font-size: 18px;
      }

      td {
          font-size: 16px;
          background-color: #ffffff;
      }

      tr:nth-child(even) {
          background-color: #f2f2f2; /* Alternatif warna baris */
      }
  }
</style>

  </head>
  <body onload="printpage()">
  <h2>
    <center>Data User</center>
  </h2>
  <table border="1" align="center">
    <tr>
      <th>NO</th>
      <th>ID User</th>
      <th>Nama</th>
      <th>Username</th>
      <th>Password</th>
    </tr>
    <?php
  include("../config/koneksi.php");
  $i = 1;
  $query = mysqli_query($config, "select * from user");
  while ($data = mysqli_fetch_array($query)) {
  echo "<tr>
  <td>$i</td>
  <td>$data[id_user]</td>
  <td>$data[nama]</td>
  <td>$data[username]</td>
  <td>$data[password]</td>
    </tr>";

    $i = $i + 1;
    }
    ?>
  </body>
  </html>

  