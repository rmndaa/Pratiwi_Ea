<?php
// Koneksi ke database
include('../config/koneksi.php'); // Pastikan koneksi ke database sudah benar

// Ambil data dari form
$id_pelanggan = $_POST['id_pelanggan'];
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$nomor_hp = $_POST['nomor_hp'];

// Cek apakah ID Pelanggan sudah ada di database
$query = "SELECT * FROM pelanggan WHERE id_pelanggan = '$id_pelanggan'";
$result = mysqli_query($config, $query);

if (mysqli_num_rows($result) > 0) {
    // Jika ID sudah ada, beri peringatan
    echo "<script>alert('ID Pelanggan sudah terdaftar. Silakan masukkan ID yang berbeda.'); window.location.href='tambah-pelanggan.php';</script>";
} else {
    // Jika ID tidak duplikat, simpan data ke database
    $query_insert = "INSERT INTO pelanggan (id_pelanggan, nama, alamat, nomor_hp) VALUES ('$id_pelanggan', '$nama', '$alamat', '$nomor_hp')";
    
    if (mysqli_query($config, $query_insert)) {
        echo "<script>alert('Pelanggan berhasil ditambahkan!'); window.location.href='tampil-pelanggan.php';</script>";
    } else {
        echo "<script>alert('Terjadi kesalahan saat menyimpan data.'); window.location.href='tambah-pelanggan.php';</script>";
    }
}
?>